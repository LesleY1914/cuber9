// Importar el paquete MySQL
const mysql = require('mysql');

// Configurar la conexión a la base de datos
const connection = mysql.createConnection({
  host: 'localhost',  // Nombre del host donde se encuentra la base de datos
  user: 'usuario_db', // Nombre de usuario de la base de datos
  password: 'contraseña_db', // Contraseña de la base de datos
  database: 'nombre_db' // Nombre de la base de datos
});

// Conectar a la base de datos
connection.connect((err) => {
  if (err) {
    console.error('Error de conexión a la base de datos: ' + err.stack);
    return;
  }
  console.log('Conexión a la base de datos exitosa con ID: ' + connection.threadId);
});

// Verificar las credenciales del usuario en el inicio de sesión
app.post('/login', (req, res) => {
  const { usuario, contraseña } = req.body;

  // Consulta SQL para buscar al usuario por nombre de usuario y contraseña hash
  const sql = 'SELECT * FROM usuarios WHERE nombre_de_usuario = ? AND contraseña_hash = ?';

  // Ejecutar la consulta SQL
  connection.query(sql, [usuario, hash(contraseña)], (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta SQL: ' + err.message);
      return res.status(500).send('Error del servidor');
    }

    if (results.length === 0) {
      return res.status(401).send('Credenciales inválidas');
    }

    return res.status(200).send('Inicio de sesión exitoso');
  });
});

// Función para generar un hash de contraseña (depende de la implementación)
function hash(password) {
  // Implementa la lógica para generar un hash de contraseña (por ejemplo, bcrypt)
}

// Cerrar la conexión a la base de datos cuando el servidor se apaga
process.on('SIGINT', () => {
  connection.end();
  console.log('Conexión a la base de datos cerrada');
  process.exit();
});

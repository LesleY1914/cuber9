document.getElementById('formSeguimiento').addEventListener('submit', function(event){
    event.preventDefault();
  
    const producto = document.querySelector('#inputProducto').value;
    const direccion = document.querySelector('#inputDireccion').value;
    const destino = document.querySelector('#inputDestino').value;
    const localidad = document.querySelector('#inputLocalidad').value;
    const estado = document.querySelector('#inputState').value;

    const seguimientos= JSON.parse(localStorage.getItem('seguimientos') || '[]');
    seguimientos.push({producto, direccion, destino, localidad, estado});
    localStorage.setItem('seguimientos', JSON.stringify(seguimientos));

    alert('Seguimiento creado correctamente')
    window.location.href="./SeguimientosUsuarios.html";
    
  });

  document.addEventListener('DOMContentLoaded', function () {
    const cerrarSesion = document.getElementById("btncerrarSesion");


    cerrarSesion.addEventListener('click', function(e){
        e.preventDefault();
      
        alert('Seguro que quieres cerrar sesión?')
      
        window.location.href ="/Login.html";
        history.replaceState(null,"", "/Login.html");                                                       

        
      
        
      });

      



});



const Detalles = document.getElementById("verDetalles");
const modalEliminar = document.getElementById("modalEliminar");
const cerrarSesion = document.getElementById("btncerrarSesion");
let eliminarTarget = null; 


function abrirModalEliminar() {
  modalEliminar.style.display = "block";
}


function cerrarModal() {
  modalEliminar.style.display = "none";
}

function abrirDetalles() {
  Detalles.style.display = "block";
}


function confirmarModal() {
  if (eliminarTarget) {
    
    eliminarTarget.parentNode.parentNode.remove();
    cerrarModal();
  }
}


function Eliminar(elemento) {
  abrirModalEliminar();
  eliminarTarget = elemento; 
}


document.querySelectorAll('.btnBorrar').forEach(btn => {
  btn.addEventListener('click', function() {
    Eliminar(this);
  });
});


window.onclick = function(event) {
  if (event.target == modalEliminar) {
    cerrarModal();
  }
}

cerrarSesion.addEventListener('click', function(e){
  e.preventDefault();

  alert('Seguro que quieres cerrar sesión?')

  window.location.href ="/Login.html";
  history.replaceState(null,"", "/Login.html");

  
});

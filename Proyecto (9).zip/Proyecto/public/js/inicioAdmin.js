document.addEventListener('DOMContentLoaded', function () {
    const cerrarSesion = document.getElementById("btncerrarSesion");


    cerrarSesion.addEventListener('click', function(e){
        e.preventDefault();
      
        alert('Seguro que quieres cerrar sesión?')
      
        window.location.href ="/Login.html";
        history.replaceState(null,"", "/Login.html");                                                       

        
      
        
      });

      



});



